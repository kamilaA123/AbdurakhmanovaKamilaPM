﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppFreeChoic.Models;

namespace WpfAppFreeChoic.Windows
{
    /// <summary>
    /// Логика взаимодействия для MainManager.xaml
    /// </summary>
    public partial class MainManager : Window
    {
        private List<Tour> _tours = new List<Tour>();
        private List<Order> _orders = new List<Order>();
        private List<User> _users = new List<User>();
        private User _currentUser;

        public MainManager(User user = null)
        {
            InitializeComponent();
            _currentUser = user;
            InitializeUIBasedOnRole();
            LoadTours();
            LoadOrders();
            LoadUsers();
        }

        private void InitializeUIBasedOnRole()
        {
            if (_currentUser == null)
            {
                _currentUser = App.CurrentUser;
            }

            // Скрываем функционал для менеджера
            if (_currentUser?.IdRole == 2)
            {
                AddTourButton.Visibility = Visibility.Collapsed;
            }
        }

        private async void LoadTours()
        {
            try
            {
                using var httpClient = new HttpClient();
                var response = await httpClient.GetAsync("http://localhost:5125/api/Tour/GetAllTours");

                if (response.IsSuccessStatusCode)
                {
                    var tours = await response.Content.ReadFromJsonAsync<List<Tour>>();
                    _tours = tours ?? new List<Tour>();
                    ToursDataGrid.ItemsSource = _tours;
                }
                else
                {
                    MessageBox.Show("Ошибка при загрузке туров", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void LoadOrders()
        {
            try
            {
                using var httpClient = new HttpClient();
                var response = await httpClient.GetAsync("http://localhost:5125/api/Order/GetAllOrder");

                if (response.IsSuccessStatusCode)
                {
                    var orders = await response.Content.ReadFromJsonAsync<List<Order>>();
                    _orders = orders ?? new List<Order>();
                    OrdersDataGrid.ItemsSource = _orders;
                }
                else
                {
                    MessageBox.Show("Ошибка при загрузке заказов", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке заказов: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void LoadUsers()
        {
            try
            {
                using var httpClient = new HttpClient();
                var response = await httpClient.GetAsync("http://localhost:5125/api/User/GetAllUsers");

                if (response.IsSuccessStatusCode)
                {
                    _users = await response.Content.ReadFromJsonAsync<List<User>>() ?? new List<User>();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке пользователей: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddTourButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUser?.IdRole == 2)
            {
                MessageBox.Show("Недостаточно прав для добавления туров", "Ошибка прав",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var addEditWindow = new AddEditTour();
            addEditWindow.Closed += (s, args) => LoadTours();
            addEditWindow.ShowDialog();
        }

        private void EditTourButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUser?.IdRole == 2)
            {
                MessageBox.Show("Недостаточно прав для редактирования туров", "Ошибка прав",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var button = (Button)sender;
            int tourId = (int)button.Tag;

            var tour = _tours.Find(t => t.IdTour == tourId);
            if (tour != null)
            {
                var addEditWindow = new AddEditTour(tour);
                addEditWindow.Closed += (s, args) => LoadTours();
                addEditWindow.ShowDialog();
            }
        }

        private async void DeleteTourButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUser?.IdRole == 2)
            {
                MessageBox.Show("Недостаточно прав для удаления туров", "Ошибка прав",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var button = (Button)sender;
            int tourId = (int)button.Tag;

            var result = MessageBox.Show("Вы уверены, что хотите удалить этот тур?",
                "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    using var httpClient = new HttpClient();
                    var response = await httpClient.PostAsync($"http://localhost:5125/api/Tour/DeleteTour/{tourId}", null);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Тур успешно удален", "Успех",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadTours();
                    }
                    else
                    {
                        var error = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Ошибка при удалении: {error}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private async void CancelOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUser?.IdRole == 2)
            {
                MessageBox.Show("Недостаточно прав для отмены заказов", "Ошибка прав",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var button = (Button)sender;
            int orderId = (int)button.Tag;

            var result = MessageBox.Show("Вы уверены, что хотите отменить этот заказ?",
                "Подтверждение отмены", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    using var httpClient = new HttpClient();
                    var response = await httpClient.PostAsync($"http://localhost:5125/api/Order/DeleteOrder/{orderId}", null);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Заказ успешно отменен", "Успех",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadOrders();
                    }
                    else
                    {
                        var error = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Ошибка при отмене заказа: {error}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadTours();
            LoadOrders();
        }

        

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите выйти?",
                "Подтверждение выхода", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Authorization authorizationWindow = new Authorization();
                authorizationWindow.Show();
                this.Close();
            }
        }

        // Вспомогательный метод для получения имени пользователя по ID
        private string GetUserName(int userId)
        {
            var user = _users.FirstOrDefault(u => u.IdUser == userId);
            return user != null ? $"{user.FirstName} {user.LastName}" : "Неизвестный пользователь";
        }

        // Вспомогательный метод для получения названия тура по ID
        private string GetTourTitle(int tourId)
        {
            var tour = _tours.FirstOrDefault(t => t.IdTour == tourId);
            return tour != null ? tour.Title : "Неизвестный тур";
        }
    }
}