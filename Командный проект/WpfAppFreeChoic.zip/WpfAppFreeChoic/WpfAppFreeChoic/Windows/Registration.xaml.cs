﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppFreeChoic.Models;

namespace WpfAppFreeChoic.Windows
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }
        private async void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            var user = new User
            {
                FirstName = FirstNameTextBox.Text.Trim(),
                LastName = LastNameTextBox.Text.Trim(),
                Patronymic = string.IsNullOrWhiteSpace(PatronymicTextBox.Text) ? "" : PatronymicTextBox.Text.Trim(),
                Email = EmailTextBox.Text.Trim(),
                PhoneNumber = PhoneNumberTextBox.Text.Trim(),
                Password = PasswordBox.Password,
                IdRole = 3 // Указываем роль менеджера
            };

                using var httpClient = new HttpClient();

                var response = await httpClient.PostAsJsonAsync("http://localhost:5125/api/User/Registration", user);

                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"{result}", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);

                    // Возврат к окну авторизации
                    Authorization authorizationWindow = new Authorization();
                    authorizationWindow.Show();
                    this.Close();
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Ошибка регистрации: {errorContent}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }


        private void LoginHyperlink_Click(object sender, RoutedEventArgs e)
        {
            //MainWindow loginWindow = new MainWindow();
            //loginWindow.Show();
            //this.Close();
        }
    }
}
