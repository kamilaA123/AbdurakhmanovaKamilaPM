﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppFreeChoic.Models;

namespace WpfAppFreeChoic.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddEditTour.xaml
    /// </summary>
    public partial class AddEditTour : Window
    {
        private Tour _tour;
        private bool _isEditMode;
        private List<TourType> _tourTypes = new List<TourType>();

        public string WindowTitle => _isEditMode ? "Редактирование тура" : "Добавление тура";

        public AddEditTour()
        {
            InitializeComponent();
            _isEditMode = false;
            _tour = new Tour();
            DataContext = this;
            LoadTourTypes();
        }
        public AddEditTour(Tour tour)
        {
            InitializeComponent();
            _isEditMode = true;
            _tour = tour;
            DataContext = this;
            LoadTourTypes();
            FillForm();
        }
        private async void LoadTourTypes()
        {
            try
            {
                using var httpClient = new HttpClient();
                var response = await httpClient.GetAsync("http://localhost:5125/api/TypeTour/GetTypeTours");

                if (response.IsSuccessStatusCode)
                {
                    _tourTypes = await response.Content.ReadFromJsonAsync<List<TourType>>() ?? new List<TourType>();
                    TourTypeComboBox.ItemsSource = _tourTypes;
                    TourTypeComboBox.DisplayMemberPath = "Name"; // Изменил с Title на Name
                    TourTypeComboBox.SelectedValuePath = "IdTourTypes";

                    if (_isEditMode && _tour.IdTourType.HasValue)
                    {
                        TourTypeComboBox.SelectedValue = _tour.IdTourType.Value;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке типов туров: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void FillForm()
        {
            TitleTextBox.Text = _tour.Title;
            FromCityTextBox.Text = _tour.FromCity;
            WhereCityTextBox.Text = _tour.WhereCity;
            DescriptionTextBox.Text = _tour.Description ?? "";

            // Конвертация DateOnly в DateTime для DatePicker
            if (_tour.DataStart.HasValue)
            {
                StartDatePicker.SelectedDate = new DateTime(_tour.DataStart.Value.Year,
                    _tour.DataStart.Value.Month, _tour.DataStart.Value.Day);
            }

            if (_tour.DataEnd.HasValue)
            {
                EndDatePicker.SelectedDate = new DateTime(_tour.DataEnd.Value.Year,
                    _tour.DataEnd.Value.Month, _tour.DataEnd.Value.Day);
            }

            PriceTextBox.Text = _tour.Price.ToString(CultureInfo.InvariantCulture);
            CountPeopleTextBox.Text = _tour.CountPeople?.ToString() ?? "";
            ImageTextBox.Text = _tour.Image ?? "";
        }

        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateForm())
                return;

            try
            {
                var tourToSave = new Tour
                {
                    IdTour = _isEditMode ? _tour.IdTour : 0,
                    Title = TitleTextBox.Text.Trim(),
                    FromCity = FromCityTextBox.Text.Trim(),
                    WhereCity = WhereCityTextBox.Text.Trim(),
                    IdTourType = TourTypeComboBox.SelectedValue as int?,
                    Description = string.IsNullOrWhiteSpace(DescriptionTextBox.Text) ? null : DescriptionTextBox.Text.Trim(),
                    DataStart = StartDatePicker.SelectedDate.HasValue ?
                        DateOnly.FromDateTime(StartDatePicker.SelectedDate.Value) : null,
                    DataEnd = EndDatePicker.SelectedDate.HasValue ?
                        DateOnly.FromDateTime(EndDatePicker.SelectedDate.Value) : null,
                    Price = decimal.Parse(PriceTextBox.Text, CultureInfo.InvariantCulture),
                    CountPeople = string.IsNullOrWhiteSpace(CountPeopleTextBox.Text) ?
                        null : int.Parse(CountPeopleTextBox.Text),
                    Image = string.IsNullOrWhiteSpace(ImageTextBox.Text) ? null : ImageTextBox.Text.Trim()
                };

                using var httpClient = new HttpClient();
                HttpResponseMessage response;

                if (_isEditMode)
                {
                    response = await httpClient.PostAsJsonAsync("http://localhost:5125/api/Tour/EditTour", tourToSave);
                }
                else
                {
                    response = await httpClient.PostAsJsonAsync("http://localhost:5125/api/Tour/AddTour", tourToSave);
                }

                if (response.IsSuccessStatusCode)
                {
                    var message = await response.Content.ReadAsStringAsync();
                    MessageBox.Show(message, "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.Close();
                }
                else
                {
                    var error = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Ошибка: {error}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ValidateForm()
        {
            if (string.IsNullOrWhiteSpace(TitleTextBox.Text) ||
                string.IsNullOrWhiteSpace(FromCityTextBox.Text) ||
                string.IsNullOrWhiteSpace(WhereCityTextBox.Text) ||
                TourTypeComboBox.SelectedValue == null)
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (!decimal.TryParse(PriceTextBox.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal price) || price <= 0)
            {
                MessageBox.Show("Введите корректную цену!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (!string.IsNullOrWhiteSpace(CountPeopleTextBox.Text) &&
                (!int.TryParse(CountPeopleTextBox.Text, out int count) || count <= 0))
            {
                MessageBox.Show("Введите корректное количество людей!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (StartDatePicker.SelectedDate.HasValue && EndDatePicker.SelectedDate.HasValue &&
                StartDatePicker.SelectedDate >= EndDatePicker.SelectedDate)
            {
                MessageBox.Show("Дата окончания должна быть позже даты начала!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
