﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppFreeChoic.Models;

namespace WpfAppFreeChoic.Windows
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class Authorization : Window
    {
        public Authorization()
        {
            InitializeComponent();
        }
        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text;
            string password = PasswordBox.Password;

            using var httpClient = new HttpClient();

            var loginRequest = new LoginRequest
            {
                Email = email,
                Password = password
            };
            var response = await httpClient.PostAsJsonAsync("http://localhost:5125/api/User/Auth", loginRequest);

            if (response.IsSuccessStatusCode)
            {
                var user = await response.Content.ReadFromJsonAsync<User>();
                if (user.IdRole == 2 || user.IdRole == 3) // Менеджер (2) или Главный менеджер (3)
                {
                    MessageBox.Show($"Добро пожаловать, {user.FirstName} {user.LastName} (Роль: {user.IdRole})");

                    MainManager mainManager = new MainManager();
                    mainManager.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Доступ запрещен. Только менеджеры и главные менеджеры могут войти в систему.");
                }
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                MessageBox.Show($"Ошибка: Проверьте почту и пароль.");
            }
        }

        private void RegisterHyperlink_Click(object sender, RoutedEventArgs e)
        {
            Registration registerWindow = new Registration();
            registerWindow.Show();
            this.Close();
        }
    }
}
