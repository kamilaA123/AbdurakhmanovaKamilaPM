﻿using System.Configuration;
using System.Data;
using System.Windows;
using WpfAppFreeChoic.Models;

namespace WpfAppFreeChoic
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static User CurrentUser { get; set; }
    }

}
