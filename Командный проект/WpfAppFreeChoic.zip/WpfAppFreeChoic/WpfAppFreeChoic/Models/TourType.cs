﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppFreeChoic.Models
{
    public class TourType
    {
        public int IdTourTypes { get; set; }
        public string Name { get; set; } = null!;
    }
}
