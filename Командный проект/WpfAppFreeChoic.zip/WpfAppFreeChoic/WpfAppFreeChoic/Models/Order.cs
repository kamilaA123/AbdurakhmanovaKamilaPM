﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WpfAppFreeChoic.Models
{
    internal class Order
    {
        public int IdOrder { get; set; }
        public int? UserId { get; set; }

        public int? TourId { get; set; }

        public DateTime? BookingDatetime { get; set; }

        public decimal TotalCost { get; set; }

        public int? CountMest { get; set; }
        
    }
}

